package control_sided;

public enum DifficultyEnum {
    easy,
    medium,
    hard,
    incomplete;
}
