package Exception;
public class InvalidSolutionException extends Exception {

    public InvalidSolutionException(String msg) {
        super(msg);
    }
    
}
