package verifies;


import java.util.ArrayList;
import java.util.List;

public abstract class dublicates {

    protected int[][] board;
    protected List<Point> emptyCells;     
    protected int[] currentCombination;   

   
    public static class Point {
        int r, c;
        public Point(int r, int c) {
            this.r = r;
            this.c = c;
        }
    }

    public dublicates(int[][] board) {
        
        this.board = board;
        this.emptyCells = new ArrayList<>();
        
      
        for (int r = 0; r < 9; r++) {
            for (int c = 0; c < 9; c++) {
                if (board[r][c] == 0) {
                    emptyCells.add(new Point(r, c));
                }
            }
        }
    }

   
    public void setCombination(int[] combination) {
        this.currentCombination = combination;
    }

 
    protected int getValueAt(int r, int c) {
       
        if (currentCombination == null) {
            return board[r][c];
        }

       
        for (int i = 0; i < emptyCells.size(); i++) {
            Point p = emptyCells.get(i);
            if (p.r == r && p.c == c) {
              
                return currentCombination[i];
            }
        }

     
        return board[r][c];
    }

 
 
    public ArrayList<Integer> find_dub(int[] rc, int x) {
        ArrayList<Integer> ind = new ArrayList<>();
        for (int i = 0; i < rc.length; i++) {
            if (rc[i] == x) {
                ind.add(i);
            }
        }
        return ind;
    }
}