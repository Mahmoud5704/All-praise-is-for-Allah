package verifies;

import java.util.ArrayList;

public class ColVerifier extends dublicates implements verifier {

    public ColVerifier(int[][] board) {
        super(board);
    }

    @Override
    public String checker(int colIndex) {
        int[] line = new int[9];

       
        for (int r = 0; r < 9; r++) {
            line[r] = getValueAt(r, colIndex);
        }

        for (int num = 1; num <= 9; num++) {
            ArrayList<Integer> duplicates = find_dub(line, num);
            if (duplicates.size() > 1) {
                return "Invalid Col " + colIndex + ": Number " + num + " repeated";
            }
        }
        return "";
    }
}