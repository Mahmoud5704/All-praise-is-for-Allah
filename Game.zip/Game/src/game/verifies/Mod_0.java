package verifies;

public class Mod_0 {

    private final RowVerifier rowVerifier;
    private final ColVerifier colVerifier;
    private final BoxVerifier boxVerifier;

    public Mod_0(int[][] board) {
       
        this.rowVerifier = new RowVerifier(board);
        this.colVerifier = new ColVerifier(board);
        this.boxVerifier = new BoxVerifier(board);
    }

    public String verifyCombination(int[] combination) {

        rowVerifier.setCombination(combination);
        colVerifier.setCombination(combination);
        boxVerifier.setCombination(combination);

        return runVerification();
    }
    
    public String verify() {
        
        rowVerifier.setCombination(null);
        colVerifier.setCombination(null);
        boxVerifier.setCombination(null);
        
        return runVerification();
    }

private String runVerification() {
        for (int i = 0; i < 9; i++) {
           
            String rowResult = rowVerifier.checker(i);
            if (!rowResult.equals("Valid")) {
                return rowResult; 
            }

            
            String colResult = colVerifier.checker(i);
            if (!colResult.equals("Valid")) {
                return colResult;
            }

          
            String boxResult = boxVerifier.checker(i);
            if (!boxResult.equals("Valid")) {
                return boxResult;
            }
        }
        
        
        return ""; 
    }
}