package verifies;

import java.util.ArrayList;

public class RowVerifier extends dublicates implements verifier {

    public RowVerifier(int[][] board) {
        super(board);
    }

    @Override
    public String checker(int rowIndex) {
        int[] line = new int[9];
        
      
        for (int c = 0; c < 9; c++) {
            line[c] = getValueAt(rowIndex, c);
        }

   
        for (int num = 1; num <= 9; num++) {
            ArrayList<Integer> duplicates = find_dub(line, num);
            if (duplicates.size() > 1) {
                return "Invalid Row " + rowIndex + ": Number " + num + " repeated at indices " + duplicates;
            }
        }
        return "";
    }
}