package verifies;

import java.util.ArrayList;

public class BoxVerifier extends dublicates implements verifier {

    public BoxVerifier(int[][] board) {
        super(board);
    }

    @Override
    public String checker(int boxIndex) {
        int[] line = new int[9];
        
        
        int startRow = (boxIndex / 3) * 3;
        int startCol = (boxIndex % 3) * 3;
        
        
        int idx = 0;
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 3; c++) {
                line[idx++] = getValueAt(startRow + r, startCol + c);
            }
        }

        for (int num = 1; num <= 9; num++) {
            ArrayList<Integer> duplicates = find_dub(line, num);
            if (duplicates.size() > 1) {
                return "Invalid Box " + boxIndex + ": Number " + num + " repeated";
            }
        }
        return "";
    }
}