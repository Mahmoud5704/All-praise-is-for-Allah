package verifies;

public interface verifier {
    String checker(int index);
}
